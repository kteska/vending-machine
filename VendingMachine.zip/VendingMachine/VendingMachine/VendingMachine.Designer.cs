﻿namespace VendingMachine
{
    partial class VendingMachine
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VendingMachine));
            this.label1 = new System.Windows.Forms.Label();
            this.ktbtnWonka = new System.Windows.Forms.Button();
            this.ktbtnReeses = new System.Windows.Forms.Button();
            this.ktbtnMm = new System.Windows.Forms.Button();
            this.ktbtnKropla = new System.Windows.Forms.Button();
            this.ktbtnEvian = new System.Windows.Forms.Button();
            this.ktbtnKubus = new System.Windows.Forms.Button();
            this.kttxtWonka = new System.Windows.Forms.TextBox();
            this.kttxtReeses = new System.Windows.Forms.TextBox();
            this.kttxtMm = new System.Windows.Forms.TextBox();
            this.kttxtKropla = new System.Windows.Forms.TextBox();
            this.kttxtEvian = new System.Windows.Forms.TextBox();
            this.kttxtKubus = new System.Windows.Forms.TextBox();
            this.ktcmbChooseCurrency = new System.Windows.Forms.ComboBox();
            this.ktcmbChoosePayment = new System.Windows.Forms.ComboBox();
            this.kttxtAmountToPay = new System.Windows.Forms.TextBox();
            this.ktlblAmountToPay = new System.Windows.Forms.Label();
            this.ktbtnCardPayment = new System.Windows.Forms.Button();
            this.ktlblPayByCard = new System.Windows.Forms.Label();
            this.ktlblChooseProducts = new System.Windows.Forms.Label();
            this.ktlblChooseCurrPay = new System.Windows.Forms.Label();
            this.ktlblPayByCash = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.ktbtn50 = new System.Windows.Forms.Button();
            this.ktbtn1 = new System.Windows.Forms.Button();
            this.ktbtn2 = new System.Windows.Forms.Button();
            this.ktbtn5 = new System.Windows.Forms.Button();
            this.ktlblDetectedMoney = new System.Windows.Forms.Label();
            this.kttxtDetectedMoney = new System.Windows.Forms.TextBox();
            this.ktbtnPayByCash = new System.Windows.Forms.Button();
            this.ktbtnGoToPayment = new System.Windows.Forms.Button();
            this.ktlblProductsAmount = new System.Windows.Forms.Label();
            this.kttxtNumProducts = new System.Windows.Forms.TextBox();
            this.kttxtDetectedMoneyEUR = new System.Windows.Forms.TextBox();
            this.ktlblEur = new System.Windows.Forms.Label();
            this.ktlblZl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Ink Free", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(315, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vending Machine";
            // 
            // ktbtnWonka
            // 
            this.ktbtnWonka.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ktbtnWonka.BackgroundImage")));
            this.ktbtnWonka.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ktbtnWonka.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtnWonka.Location = new System.Drawing.Point(210, 95);
            this.ktbtnWonka.Name = "ktbtnWonka";
            this.ktbtnWonka.Size = new System.Drawing.Size(137, 99);
            this.ktbtnWonka.TabIndex = 1;
            this.ktbtnWonka.UseVisualStyleBackColor = true;
            this.ktbtnWonka.Click += new System.EventHandler(this.ktbtnWonka_Click);
            // 
            // ktbtnReeses
            // 
            this.ktbtnReeses.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ktbtnReeses.BackgroundImage")));
            this.ktbtnReeses.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ktbtnReeses.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtnReeses.Location = new System.Drawing.Point(353, 95);
            this.ktbtnReeses.Name = "ktbtnReeses";
            this.ktbtnReeses.Size = new System.Drawing.Size(137, 99);
            this.ktbtnReeses.TabIndex = 2;
            this.ktbtnReeses.UseVisualStyleBackColor = true;
            this.ktbtnReeses.Click += new System.EventHandler(this.ktbtnReeses_Click);
            // 
            // ktbtnMm
            // 
            this.ktbtnMm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ktbtnMm.BackgroundImage")));
            this.ktbtnMm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ktbtnMm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtnMm.Location = new System.Drawing.Point(496, 95);
            this.ktbtnMm.Name = "ktbtnMm";
            this.ktbtnMm.Size = new System.Drawing.Size(137, 99);
            this.ktbtnMm.TabIndex = 3;
            this.ktbtnMm.UseVisualStyleBackColor = true;
            this.ktbtnMm.Click += new System.EventHandler(this.ktbtnMm_Click);
            // 
            // ktbtnKropla
            // 
            this.ktbtnKropla.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ktbtnKropla.BackgroundImage")));
            this.ktbtnKropla.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ktbtnKropla.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtnKropla.Location = new System.Drawing.Point(210, 239);
            this.ktbtnKropla.Name = "ktbtnKropla";
            this.ktbtnKropla.Size = new System.Drawing.Size(137, 96);
            this.ktbtnKropla.TabIndex = 4;
            this.ktbtnKropla.UseVisualStyleBackColor = true;
            this.ktbtnKropla.Click += new System.EventHandler(this.ktbtnKropla_Click);
            // 
            // ktbtnEvian
            // 
            this.ktbtnEvian.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ktbtnEvian.BackgroundImage")));
            this.ktbtnEvian.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ktbtnEvian.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtnEvian.Location = new System.Drawing.Point(353, 239);
            this.ktbtnEvian.Name = "ktbtnEvian";
            this.ktbtnEvian.Size = new System.Drawing.Size(137, 96);
            this.ktbtnEvian.TabIndex = 5;
            this.ktbtnEvian.UseVisualStyleBackColor = true;
            this.ktbtnEvian.Click += new System.EventHandler(this.ktbtnEvian_Click);
            // 
            // ktbtnKubus
            // 
            this.ktbtnKubus.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ktbtnKubus.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ktbtnKubus.BackgroundImage")));
            this.ktbtnKubus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ktbtnKubus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtnKubus.Location = new System.Drawing.Point(496, 239);
            this.ktbtnKubus.Name = "ktbtnKubus";
            this.ktbtnKubus.Size = new System.Drawing.Size(137, 95);
            this.ktbtnKubus.TabIndex = 6;
            this.ktbtnKubus.UseVisualStyleBackColor = false;
            this.ktbtnKubus.Click += new System.EventHandler(this.ktbtnKubus_Click);
            // 
            // kttxtWonka
            // 
            this.kttxtWonka.BackColor = System.Drawing.Color.Ivory;
            this.kttxtWonka.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kttxtWonka.Location = new System.Drawing.Point(245, 200);
            this.kttxtWonka.Name = "kttxtWonka";
            this.kttxtWonka.ReadOnly = true;
            this.kttxtWonka.Size = new System.Drawing.Size(65, 26);
            this.kttxtWonka.TabIndex = 7;
            this.kttxtWonka.Text = "8.00 zł";
            this.kttxtWonka.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // kttxtReeses
            // 
            this.kttxtReeses.BackColor = System.Drawing.Color.Ivory;
            this.kttxtReeses.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kttxtReeses.Location = new System.Drawing.Point(391, 200);
            this.kttxtReeses.Name = "kttxtReeses";
            this.kttxtReeses.ReadOnly = true;
            this.kttxtReeses.Size = new System.Drawing.Size(65, 26);
            this.kttxtReeses.TabIndex = 8;
            this.kttxtReeses.Text = "6.00 zł";
            this.kttxtReeses.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // kttxtMm
            // 
            this.kttxtMm.BackColor = System.Drawing.Color.Ivory;
            this.kttxtMm.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kttxtMm.Location = new System.Drawing.Point(531, 200);
            this.kttxtMm.Name = "kttxtMm";
            this.kttxtMm.ReadOnly = true;
            this.kttxtMm.Size = new System.Drawing.Size(65, 26);
            this.kttxtMm.TabIndex = 9;
            this.kttxtMm.Text = "4.00 zł";
            this.kttxtMm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // kttxtKropla
            // 
            this.kttxtKropla.BackColor = System.Drawing.Color.Ivory;
            this.kttxtKropla.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kttxtKropla.Location = new System.Drawing.Point(245, 341);
            this.kttxtKropla.Name = "kttxtKropla";
            this.kttxtKropla.Size = new System.Drawing.Size(65, 26);
            this.kttxtKropla.TabIndex = 10;
            this.kttxtKropla.Text = "3.50 zł";
            this.kttxtKropla.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // kttxtEvian
            // 
            this.kttxtEvian.BackColor = System.Drawing.Color.Ivory;
            this.kttxtEvian.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kttxtEvian.Location = new System.Drawing.Point(391, 341);
            this.kttxtEvian.Name = "kttxtEvian";
            this.kttxtEvian.ReadOnly = true;
            this.kttxtEvian.Size = new System.Drawing.Size(65, 26);
            this.kttxtEvian.TabIndex = 11;
            this.kttxtEvian.Text = "2.50 zł";
            this.kttxtEvian.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // kttxtKubus
            // 
            this.kttxtKubus.BackColor = System.Drawing.Color.Ivory;
            this.kttxtKubus.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kttxtKubus.Location = new System.Drawing.Point(531, 341);
            this.kttxtKubus.Name = "kttxtKubus";
            this.kttxtKubus.ReadOnly = true;
            this.kttxtKubus.Size = new System.Drawing.Size(65, 26);
            this.kttxtKubus.TabIndex = 12;
            this.kttxtKubus.Text = "4.50 zł";
            this.kttxtKubus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ktcmbChooseCurrency
            // 
            this.ktcmbChooseCurrency.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktcmbChooseCurrency.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktcmbChooseCurrency.FormattingEnabled = true;
            this.ktcmbChooseCurrency.Items.AddRange(new object[] {
            "PLN",
            "EUR"});
            this.ktcmbChooseCurrency.Location = new System.Drawing.Point(21, 107);
            this.ktcmbChooseCurrency.Name = "ktcmbChooseCurrency";
            this.ktcmbChooseCurrency.Size = new System.Drawing.Size(167, 22);
            this.ktcmbChooseCurrency.TabIndex = 15;
            this.ktcmbChooseCurrency.Text = "Select currency";
            this.ktcmbChooseCurrency.SelectedIndexChanged += new System.EventHandler(this.ktcmbChooseCurrency_SelectedIndexChanged);
            // 
            // ktcmbChoosePayment
            // 
            this.ktcmbChoosePayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktcmbChoosePayment.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktcmbChoosePayment.FormattingEnabled = true;
            this.ktcmbChoosePayment.Items.AddRange(new object[] {
            "Card",
            "Cash"});
            this.ktcmbChoosePayment.Location = new System.Drawing.Point(21, 144);
            this.ktcmbChoosePayment.Name = "ktcmbChoosePayment";
            this.ktcmbChoosePayment.Size = new System.Drawing.Size(167, 22);
            this.ktcmbChoosePayment.TabIndex = 16;
            this.ktcmbChoosePayment.Text = "Select payment method";
            this.ktcmbChoosePayment.SelectedIndexChanged += new System.EventHandler(this.ktcmbChoosePayment_SelectedIndexChanged);
            // 
            // kttxtAmountToPay
            // 
            this.kttxtAmountToPay.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.kttxtAmountToPay.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kttxtAmountToPay.Location = new System.Drawing.Point(391, 402);
            this.kttxtAmountToPay.Name = "kttxtAmountToPay";
            this.kttxtAmountToPay.ReadOnly = true;
            this.kttxtAmountToPay.Size = new System.Drawing.Size(65, 22);
            this.kttxtAmountToPay.TabIndex = 17;
            this.kttxtAmountToPay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ktlblAmountToPay
            // 
            this.ktlblAmountToPay.AutoSize = true;
            this.ktlblAmountToPay.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ktlblAmountToPay.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktlblAmountToPay.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ktlblAmountToPay.Location = new System.Drawing.Point(374, 385);
            this.ktlblAmountToPay.Name = "ktlblAmountToPay";
            this.ktlblAmountToPay.Size = new System.Drawing.Size(101, 14);
            this.ktlblAmountToPay.TabIndex = 18;
            this.ktlblAmountToPay.Text = "Amount to pay";
            // 
            // ktbtnCardPayment
            // 
            this.ktbtnCardPayment.BackColor = System.Drawing.SystemColors.Control;
            this.ktbtnCardPayment.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ktbtnCardPayment.BackgroundImage")));
            this.ktbtnCardPayment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ktbtnCardPayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtnCardPayment.Location = new System.Drawing.Point(38, 249);
            this.ktbtnCardPayment.Name = "ktbtnCardPayment";
            this.ktbtnCardPayment.Size = new System.Drawing.Size(126, 83);
            this.ktbtnCardPayment.TabIndex = 19;
            this.ktbtnCardPayment.UseVisualStyleBackColor = false;
            this.ktbtnCardPayment.Click += new System.EventHandler(this.ktbtnCardPayment_Click);
            // 
            // ktlblPayByCard
            // 
            this.ktlblPayByCard.AutoSize = true;
            this.ktlblPayByCard.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ktlblPayByCard.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktlblPayByCard.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ktlblPayByCard.Location = new System.Drawing.Point(56, 224);
            this.ktlblPayByCard.Name = "ktlblPayByCard";
            this.ktlblPayByCard.Size = new System.Drawing.Size(95, 18);
            this.ktlblPayByCard.TabIndex = 20;
            this.ktlblPayByCard.Text = "Pay by card";
            // 
            // ktlblChooseProducts
            // 
            this.ktlblChooseProducts.AutoSize = true;
            this.ktlblChooseProducts.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ktlblChooseProducts.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktlblChooseProducts.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ktlblChooseProducts.Location = new System.Drawing.Point(262, 63);
            this.ktlblChooseProducts.Name = "ktlblChooseProducts";
            this.ktlblChooseProducts.Size = new System.Drawing.Size(334, 18);
            this.ktlblChooseProducts.TabIndex = 21;
            this.ktlblChooseProducts.Text = "Choose what products you would like to buy";
            // 
            // ktlblChooseCurrPay
            // 
            this.ktlblChooseCurrPay.AutoSize = true;
            this.ktlblChooseCurrPay.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ktlblChooseCurrPay.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktlblChooseCurrPay.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ktlblChooseCurrPay.Location = new System.Drawing.Point(38, 63);
            this.ktlblChooseCurrPay.Name = "ktlblChooseCurrPay";
            this.ktlblChooseCurrPay.Size = new System.Drawing.Size(135, 28);
            this.ktlblChooseCurrPay.TabIndex = 22;
            this.ktlblChooseCurrPay.Text = "Choose currency and\r\npayment method";
            // 
            // ktlblPayByCash
            // 
            this.ktlblPayByCash.AutoSize = true;
            this.ktlblPayByCash.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ktlblPayByCash.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktlblPayByCash.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ktlblPayByCash.Location = new System.Drawing.Point(700, 63);
            this.ktlblPayByCash.Name = "ktlblPayByCash";
            this.ktlblPayByCash.Size = new System.Drawing.Size(96, 18);
            this.ktlblPayByCash.TabIndex = 23;
            this.ktlblPayByCash.Text = "Pay by cash";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // ktbtn50
            // 
            this.ktbtn50.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ktbtn50.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtn50.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktbtn50.Location = new System.Drawing.Point(689, 107);
            this.ktbtn50.Name = "ktbtn50";
            this.ktbtn50.Size = new System.Drawing.Size(52, 37);
            this.ktbtn50.TabIndex = 24;
            this.ktbtn50.Text = "0.50";
            this.ktbtn50.UseVisualStyleBackColor = false;
            this.ktbtn50.Click += new System.EventHandler(this.ktbtn50_Click);
            // 
            // ktbtn1
            // 
            this.ktbtn1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ktbtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtn1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktbtn1.Location = new System.Drawing.Point(758, 107);
            this.ktbtn1.Name = "ktbtn1";
            this.ktbtn1.Size = new System.Drawing.Size(52, 37);
            this.ktbtn1.TabIndex = 25;
            this.ktbtn1.Text = "1.00";
            this.ktbtn1.UseVisualStyleBackColor = false;
            this.ktbtn1.Click += new System.EventHandler(this.ktbtn1_Click);
            // 
            // ktbtn2
            // 
            this.ktbtn2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ktbtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtn2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktbtn2.Location = new System.Drawing.Point(689, 157);
            this.ktbtn2.Name = "ktbtn2";
            this.ktbtn2.Size = new System.Drawing.Size(52, 37);
            this.ktbtn2.TabIndex = 26;
            this.ktbtn2.Text = "2.00";
            this.ktbtn2.UseVisualStyleBackColor = false;
            this.ktbtn2.Click += new System.EventHandler(this.ktbtn2_Click);
            // 
            // ktbtn5
            // 
            this.ktbtn5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ktbtn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtn5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktbtn5.Location = new System.Drawing.Point(758, 157);
            this.ktbtn5.Name = "ktbtn5";
            this.ktbtn5.Size = new System.Drawing.Size(52, 37);
            this.ktbtn5.TabIndex = 27;
            this.ktbtn5.Text = "5.00";
            this.ktbtn5.UseVisualStyleBackColor = false;
            this.ktbtn5.Click += new System.EventHandler(this.ktbtn5_Click);
            // 
            // ktlblDetectedMoney
            // 
            this.ktlblDetectedMoney.AutoSize = true;
            this.ktlblDetectedMoney.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ktlblDetectedMoney.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktlblDetectedMoney.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ktlblDetectedMoney.Location = new System.Drawing.Point(695, 239);
            this.ktlblDetectedMoney.Name = "ktlblDetectedMoney";
            this.ktlblDetectedMoney.Size = new System.Drawing.Size(115, 28);
            this.ktlblDetectedMoney.TabIndex = 28;
            this.ktlblDetectedMoney.Text = "Detected amount\r\nof money";
            // 
            // kttxtDetectedMoney
            // 
            this.kttxtDetectedMoney.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.kttxtDetectedMoney.Location = new System.Drawing.Point(705, 277);
            this.kttxtDetectedMoney.Name = "kttxtDetectedMoney";
            this.kttxtDetectedMoney.ReadOnly = true;
            this.kttxtDetectedMoney.Size = new System.Drawing.Size(100, 20);
            this.kttxtDetectedMoney.TabIndex = 29;
            this.kttxtDetectedMoney.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ktbtnPayByCash
            // 
            this.ktbtnPayByCash.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ktbtnPayByCash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtnPayByCash.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktbtnPayByCash.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ktbtnPayByCash.Location = new System.Drawing.Point(705, 303);
            this.ktbtnPayByCash.Name = "ktbtnPayByCash";
            this.ktbtnPayByCash.Size = new System.Drawing.Size(100, 38);
            this.ktbtnPayByCash.TabIndex = 30;
            this.ktbtnPayByCash.Text = "PAYMENT";
            this.ktbtnPayByCash.UseVisualStyleBackColor = false;
            this.ktbtnPayByCash.Click += new System.EventHandler(this.ktbtnPayByCash_Click);
            // 
            // ktbtnGoToPayment
            // 
            this.ktbtnGoToPayment.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ktbtnGoToPayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ktbtnGoToPayment.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktbtnGoToPayment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ktbtnGoToPayment.Location = new System.Drawing.Point(531, 385);
            this.ktbtnGoToPayment.Name = "ktbtnGoToPayment";
            this.ktbtnGoToPayment.Size = new System.Drawing.Size(75, 48);
            this.ktbtnGoToPayment.TabIndex = 31;
            this.ktbtnGoToPayment.Text = "Go to payment";
            this.ktbtnGoToPayment.UseVisualStyleBackColor = false;
            this.ktbtnGoToPayment.Click += new System.EventHandler(this.ktbtnGoToPayment_Click);
            // 
            // ktlblProductsAmount
            // 
            this.ktlblProductsAmount.AutoSize = true;
            this.ktlblProductsAmount.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktlblProductsAmount.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ktlblProductsAmount.Location = new System.Drawing.Point(217, 385);
            this.ktlblProductsAmount.Name = "ktlblProductsAmount";
            this.ktlblProductsAmount.Size = new System.Drawing.Size(130, 14);
            this.ktlblProductsAmount.TabIndex = 32;
            this.ktlblProductsAmount.Text = "Number of products";
            // 
            // kttxtNumProducts
            // 
            this.kttxtNumProducts.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.kttxtNumProducts.Location = new System.Drawing.Point(245, 403);
            this.kttxtNumProducts.Name = "kttxtNumProducts";
            this.kttxtNumProducts.ReadOnly = true;
            this.kttxtNumProducts.Size = new System.Drawing.Size(65, 20);
            this.kttxtNumProducts.TabIndex = 33;
            this.kttxtNumProducts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // kttxtDetectedMoneyEUR
            // 
            this.kttxtDetectedMoneyEUR.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.kttxtDetectedMoneyEUR.Location = new System.Drawing.Point(390, 430);
            this.kttxtDetectedMoneyEUR.Name = "kttxtDetectedMoneyEUR";
            this.kttxtDetectedMoneyEUR.ReadOnly = true;
            this.kttxtDetectedMoneyEUR.Size = new System.Drawing.Size(66, 20);
            this.kttxtDetectedMoneyEUR.TabIndex = 35;
            this.kttxtDetectedMoneyEUR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ktlblEur
            // 
            this.ktlblEur.AutoSize = true;
            this.ktlblEur.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktlblEur.Location = new System.Drawing.Point(462, 434);
            this.ktlblEur.Name = "ktlblEur";
            this.ktlblEur.Size = new System.Drawing.Size(34, 16);
            this.ktlblEur.TabIndex = 36;
            this.ktlblEur.Text = "euro";
            // 
            // ktlblZl
            // 
            this.ktlblZl.AutoSize = true;
            this.ktlblZl.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ktlblZl.Location = new System.Drawing.Point(462, 408);
            this.ktlblZl.Name = "ktlblZl";
            this.ktlblZl.Size = new System.Drawing.Size(18, 16);
            this.ktlblZl.TabIndex = 37;
            this.ktlblZl.Text = "zł";
            // 
            // VendingMachine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(841, 457);
            this.Controls.Add(this.ktlblZl);
            this.Controls.Add(this.ktlblEur);
            this.Controls.Add(this.kttxtDetectedMoneyEUR);
            this.Controls.Add(this.kttxtNumProducts);
            this.Controls.Add(this.ktlblProductsAmount);
            this.Controls.Add(this.ktbtnGoToPayment);
            this.Controls.Add(this.ktbtnPayByCash);
            this.Controls.Add(this.kttxtDetectedMoney);
            this.Controls.Add(this.ktlblDetectedMoney);
            this.Controls.Add(this.ktbtn5);
            this.Controls.Add(this.ktbtn2);
            this.Controls.Add(this.ktbtn1);
            this.Controls.Add(this.ktbtn50);
            this.Controls.Add(this.ktlblPayByCash);
            this.Controls.Add(this.ktlblChooseCurrPay);
            this.Controls.Add(this.ktlblChooseProducts);
            this.Controls.Add(this.ktlblPayByCard);
            this.Controls.Add(this.ktbtnCardPayment);
            this.Controls.Add(this.ktlblAmountToPay);
            this.Controls.Add(this.kttxtAmountToPay);
            this.Controls.Add(this.ktcmbChoosePayment);
            this.Controls.Add(this.ktcmbChooseCurrency);
            this.Controls.Add(this.kttxtKubus);
            this.Controls.Add(this.kttxtEvian);
            this.Controls.Add(this.kttxtKropla);
            this.Controls.Add(this.kttxtMm);
            this.Controls.Add(this.kttxtReeses);
            this.Controls.Add(this.kttxtWonka);
            this.Controls.Add(this.ktbtnKubus);
            this.Controls.Add(this.ktbtnEvian);
            this.Controls.Add(this.ktbtnKropla);
            this.Controls.Add(this.ktbtnMm);
            this.Controls.Add(this.ktbtnReeses);
            this.Controls.Add(this.ktbtnWonka);
            this.Controls.Add(this.label1);
            this.Name = "VendingMachine";
            this.Text = "Vending Machine";
            this.Load += new System.EventHandler(this.VendingMachine_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ktbtnWonka;
        private System.Windows.Forms.Button ktbtnReeses;
        private System.Windows.Forms.Button ktbtnMm;
        private System.Windows.Forms.Button ktbtnKropla;
        private System.Windows.Forms.Button ktbtnEvian;
        private System.Windows.Forms.Button ktbtnKubus;
        private System.Windows.Forms.TextBox kttxtWonka;
        private System.Windows.Forms.TextBox kttxtReeses;
        private System.Windows.Forms.TextBox kttxtMm;
        private System.Windows.Forms.TextBox kttxtKropla;
        private System.Windows.Forms.TextBox kttxtEvian;
        private System.Windows.Forms.TextBox kttxtKubus;
        private System.Windows.Forms.ComboBox ktcmbChooseCurrency;
        private System.Windows.Forms.ComboBox ktcmbChoosePayment;
        private System.Windows.Forms.TextBox kttxtAmountToPay;
        private System.Windows.Forms.Label ktlblAmountToPay;
        private System.Windows.Forms.Button ktbtnCardPayment;
        private System.Windows.Forms.Label ktlblPayByCard;
        private System.Windows.Forms.Label ktlblChooseProducts;
        private System.Windows.Forms.Label ktlblChooseCurrPay;
        private System.Windows.Forms.Label ktlblPayByCash;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button ktbtn5;
        private System.Windows.Forms.Button ktbtn2;
        private System.Windows.Forms.Button ktbtn1;
        private System.Windows.Forms.Button ktbtn50;
        private System.Windows.Forms.Button ktbtnPayByCash;
        private System.Windows.Forms.TextBox kttxtDetectedMoney;
        private System.Windows.Forms.Label ktlblDetectedMoney;
        private System.Windows.Forms.Button ktbtnGoToPayment;
        private System.Windows.Forms.TextBox kttxtNumProducts;
        private System.Windows.Forms.Label ktlblProductsAmount;
        private System.Windows.Forms.Label ktlblEur;
        private System.Windows.Forms.TextBox kttxtDetectedMoneyEUR;
        private System.Windows.Forms.Label ktlblZl;
    }
}

