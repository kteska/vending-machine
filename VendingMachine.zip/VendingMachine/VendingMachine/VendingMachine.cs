﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VendingMachine
{
    public partial class VendingMachine : Form
    {
        private void VendingMachine_Load(object sender, EventArgs e) { }

        int ktNumProducts = 0;
        float ktAmountToPay = 0;
        float ktDetectedMoney = 0;
        float[] ktDenominationValues = {
            5, 2, 1, 0.50F
        };
        float[] ktDenominationValuesEUR =
        {
            2, 1, 0.50F
        };
        public struct ktDemoninations
        {
            public float Count;
            public float Value;
        }
        ktDemoninations[] ktDemoninationsContainer;
        ktDemoninations[] ktDemoninationContainerEUR;
        float ktChange;
        ktDemoninations[] ktChangeDemoninations;

        public VendingMachine()
        {
            InitializeComponent();
            // prepare form and hide unnecessary controls
            ktlblChooseCurrPay.Visible = false;
            ktcmbChooseCurrency.Visible = false;
            ktcmbChoosePayment.Visible = false;
            ktlblPayByCard.Visible = false;
            ktbtnCardPayment.Visible = false;
            ktlblPayByCash.Visible = false;
            ktbtn50.Visible = false;
            ktbtn1.Visible = false;
            ktbtn2.Visible = false;
            ktbtn5.Visible = false;
            ktlblDetectedMoney.Visible = false;
            kttxtDetectedMoney.Visible = false;
            ktbtnPayByCash.Visible = false;
            kttxtDetectedMoneyEUR.Visible = false;
            ktlblEur.Visible = false;
            //
            kttxtNumProducts.Text = ktNumProducts.ToString();
            kttxtAmountToPay.Text = ktAmountToPay.ToString();
            ktDemoninationsContainer = new ktDemoninations[ktDenominationValues.Length];
            ktDemoninationContainerEUR = new ktDemoninations[ktDenominationValuesEUR.Length];
            ktFillMoneyContainer();
            ktCalcCapital();
            ktCalcCapitalEUR();
        }

        public void ktFillMoneyContainer()
        {
            int ktCount = 10;
            for (int i = 0; i < ktDemoninationsContainer.Length; i++)
            {
                ktDemoninationsContainer[i].Value = ktDenominationValues[i];
                ktDemoninationsContainer[i].Count = ktCount;
            }
            for (int i = 0; i < ktDemoninationContainerEUR.Length; i++)
            {
                ktDemoninationContainerEUR[i].Value = ktDenominationValuesEUR[i];
                ktDemoninationContainerEUR[i].Count = ktCount;
            }
        }

        public float ktCalcCapital()
        {
            float ktCapital = 0;
            for (int i = 0; i < ktDemoninationsContainer.Length; i++)
            {
                ktCapital += ktDemoninationsContainer[i].Value * ktDemoninationsContainer[i].Count;
            }
            return ktCapital;
        }

        public float ktCalcCapitalEUR()
        {
            float ktCapital = 0;
            for (int i = 0; i < ktDemoninationContainerEUR.Length; i++)
            {
                ktCapital += ktDemoninationContainerEUR[i].Value * ktDemoninationContainerEUR[i].Count;
            }
            return ktCapital;
        }

        private void ktbtnGoToPayment_Click(object sender, EventArgs e)
        {
            ktlblChooseCurrPay.Visible = true;
            ktcmbChooseCurrency.Visible = true;
            ktcmbChoosePayment.Visible = true;
            ktbtnGoToPayment.Enabled = false;
        }

        private void ktcmbChoosePayment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((String)ktcmbChoosePayment.SelectedItem == "Card")
            {
                if (ktcmbChooseCurrency.SelectedItem == null)
                {
                    errorProvider1.SetError(ktcmbChooseCurrency, "You forgot about currency");
                    ktcmbChoosePayment.SelectedItem = null;
                    return;
                }
                else
                {
                    errorProvider1.Dispose();
                    ktlblPayByCard.Visible = true;
                    ktbtnCardPayment.Visible = true;
                    ktlblPayByCash.Visible = false;
                    ktbtn50.Visible = false;
                    ktbtn1.Visible = false;
                    ktbtn2.Visible = false;
                    ktbtn5.Visible = false;
                    ktlblDetectedMoney.Visible = false;
                    kttxtDetectedMoney.Visible = false;
                    ktbtnPayByCash.Visible = false;
                }
                
            }
            else
            {
                if (ktcmbChooseCurrency.SelectedItem == null)
                {
                    errorProvider1.SetError(ktcmbChooseCurrency, "You forgot about currency");
                    return;
                }
                else
                {
                    ktlblPayByCash.Visible = true;
                    ktbtn50.Visible = true;
                    ktbtn1.Visible = true;
                    ktbtn2.Visible = true;
                    ktbtn5.Visible = true;
                    ktlblDetectedMoney.Visible = true;
                    kttxtDetectedMoney.Visible = true;
                    ktbtnPayByCash.Visible = true;
                    ktlblPayByCard.Visible = false;
                    ktbtnCardPayment.Visible = false;
                }
                
            }
        }

        private void ktbtnWonka_Click(object sender, EventArgs e)
        {
            float ktWonkaPrice = 8.00F;
            ktAmountToPay += ktWonkaPrice;
            kttxtAmountToPay.Text = ktAmountToPay.ToString();
            kttxtDetectedMoneyEUR.Text = ((float)Math.Floor(ktAmountToPay / 4.00F)).ToString();
            ktNumProducts++;
            kttxtNumProducts.Text = ktNumProducts.ToString();
        }

        private void ktbtnReeses_Click(object sender, EventArgs e)
        {
            float ktReesesPrice = 6.00F;
            ktAmountToPay += ktReesesPrice;
            kttxtAmountToPay.Text = ktAmountToPay.ToString();
            kttxtDetectedMoneyEUR.Text = ((float)Math.Floor(ktAmountToPay / 4.00F)).ToString();
            ktNumProducts++;
            kttxtNumProducts.Text = ktNumProducts.ToString();
        }

        private void ktbtnMm_Click(object sender, EventArgs e)
        {
            float ktMmPrice = 4.00F;
            ktAmountToPay += ktMmPrice;
            kttxtAmountToPay.Text = ktAmountToPay.ToString();
            kttxtDetectedMoneyEUR.Text = ((float)Math.Floor(ktAmountToPay / 4.00F)).ToString();
            ktNumProducts++;
            kttxtNumProducts.Text = ktNumProducts.ToString();
        }

        private void ktbtnKropla_Click(object sender, EventArgs e)
        {
            float ktKroplaPrice = 3.50F;
            ktAmountToPay += ktKroplaPrice;
            kttxtAmountToPay.Text = ktAmountToPay.ToString();
            kttxtDetectedMoneyEUR.Text = ((float)Math.Floor(ktAmountToPay / 4.00F)).ToString();
            ktNumProducts++;
            kttxtNumProducts.Text = ktNumProducts.ToString();
        }

        private void ktbtnEvian_Click(object sender, EventArgs e)
        {
            float ktEvianPrice = 2.50F;
            ktAmountToPay += ktEvianPrice;
            kttxtAmountToPay.Text = ktAmountToPay.ToString();
            kttxtDetectedMoneyEUR.Text = ((float)Math.Floor(ktAmountToPay / 4.00F)).ToString();
            ktNumProducts++;
            kttxtNumProducts.Text = ktNumProducts.ToString();
        }

        private void ktbtnKubus_Click(object sender, EventArgs e)
        {
            float ktKubusPrice = 4.50F;
            ktAmountToPay += ktKubusPrice;
            kttxtAmountToPay.Text = ktAmountToPay.ToString();
            kttxtDetectedMoneyEUR.Text = ((float)Math.Floor(ktAmountToPay / 4.00F)).ToString();
            ktNumProducts++;
            kttxtNumProducts.Text = ktNumProducts.ToString();
        }

        private void ktbtnCardPayment_Click(object sender, EventArgs e)
        {
            if ((String)ktcmbChooseCurrency.SelectedItem == null)
            {
                errorProvider1.SetError(ktcmbChooseCurrency, "You forgot about currency!");
                return;
            }
            else if ((String)ktcmbChooseCurrency.SelectedItem == "PLN")
            {
                errorProvider1.Dispose();
                MessageBox.Show("Successful payment - " + ktAmountToPay + " zł. Thank you for using our vending machines. Have a nice day!", "Successful payment");
                
                ktReset();
            }
            else if ((String)ktcmbChooseCurrency.SelectedItem == "EUR")
            {
                errorProvider1.Dispose();
                MessageBox.Show("Successful payment - " + kttxtDetectedMoneyEUR.Text + " euro. Thank you for using our vending machines. Have a nice day!", "Successful payment");
                int ktAmount = 0;
                kttxtAmountToPay.Text = ktAmount.ToString();
                kttxtDetectedMoneyEUR.Text = ktAmount.ToString();
                ktReset();
            }  
        }

        private void ktbtn50_Click(object sender, EventArgs e)
        {
            float ktValue = 0.50F;
            ktDetectedMoney += ktValue;
            kttxtDetectedMoney.Text = ktDetectedMoney.ToString();
            if ((String)ktcmbChooseCurrency.SelectedItem == "PLN")
            {
                ktDemoninationsContainer[3].Count += 1;
            }
            else
            {
                ktDemoninationContainerEUR[2].Count += 1;
            }
            ktCalcCapital();
            ktCalcCapitalEUR();
        }

        private void ktbtn1_Click(object sender, EventArgs e)
        {
            float ktValue = 1.00F;
            ktDetectedMoney += ktValue;
            kttxtDetectedMoney.Text = ktDetectedMoney.ToString();
            if ((String)ktcmbChooseCurrency.SelectedItem == "PLN")
            {
                ktDemoninationsContainer[2].Count += 1;
            }
            else
            {
                ktDemoninationContainerEUR[1].Count += 1;
            }
            ktCalcCapital();
            ktCalcCapitalEUR();
        }

        private void ktbtn2_Click(object sender, EventArgs e)
        {
            float ktValue = 2.00F;
            ktDetectedMoney += ktValue;
            kttxtDetectedMoney.Text = ktDetectedMoney.ToString();
            if ((String)ktcmbChooseCurrency.SelectedItem == "PLN")
            {
                ktDemoninationsContainer[1].Count += 1;
            }
            else
            {
                ktDemoninationContainerEUR[0].Count += 1;
            }
            ktCalcCapital();
            ktCalcCapitalEUR();
        }

        private void ktbtn5_Click(object sender, EventArgs e)
        {
            float ktValue = 5.00F;
            ktDetectedMoney += ktValue;
            kttxtDetectedMoney.Text = ktDetectedMoney.ToString();
            ktDemoninationsContainer[0].Count += 1;
            ktCalcCapital();
        }

        // algorithm for calculating change for the user
        public void ktCalcChange(ktDemoninations[] arr, float change, float[] values)
        {
            ktChangeDemoninations = new ktDemoninations[values.Length];

            for (int i = 0; i < arr.Length; i++)
            {
                if (change > 0)
                {
                    if (change >= arr[i].Value && arr[i].Count > 0)
                    {
                        int ktDemValuesAmount = Convert.ToInt32(Math.Floor(change / arr[i].Value));
                        // substract amount of nominal
                        arr[i].Count -= ktDemValuesAmount;
                            
                        change = change - (arr[i].Value * ktDemValuesAmount);
                        // add to changeDem array
                        ktChangeDemoninations[i].Value = ktDemoninationsContainer[i].Value;
                        ktChangeDemoninations[i].Count = ktDemValuesAmount;
                    }
                }
            }
        }

        private void ktbtnPayByCash_Click(object sender, EventArgs e)
        {
            if ((String)ktcmbChooseCurrency.SelectedItem == null)
            {
                errorProvider1.SetError(ktcmbChooseCurrency, "You forgot about currency!");
                return;
            }
            else if ((String)ktcmbChooseCurrency.SelectedItem == "PLN")
            {
                errorProvider1.Dispose();
                if (ktDetectedMoney > ktCalcCapital())
                    MessageBox.Show("I'm sorry but I can't give you a change. Could you pay by card?", "The message");
                else
                {
                    if (ktDetectedMoney < ktAmountToPay)
                        errorProvider1.SetError(ktbtnPayByCash, "It's not enough money.");
                    else
                    {
                        errorProvider1.Dispose();
                        ktChange = ktDetectedMoney - ktAmountToPay;
                        ktCalcChange(ktDemoninationsContainer, ktChange, ktDenominationValues);

                        float ktNominalType5 = 5;
                        float ktNominalType2 = 2;
                        float ktNominalType1 = 1;
                        float ktNominalType50 = 0.50F;
                        float ktNum5 = 0;
                        float ktNum2 = 0;
                        float ktNum1 = 0;
                        float ktNum50 = 0;
                        ktNominalType5 = ktChangeDemoninations[0].Value;
                        ktNum5 = ktChangeDemoninations[0].Count;

                        ktNominalType2 = ktChangeDemoninations[1].Value;
                        ktNum2 = ktChangeDemoninations[1].Count;

                        ktNominalType1 = ktChangeDemoninations[2].Value;
                        ktNum1 = ktChangeDemoninations[2].Count;

                        ktNominalType50 = ktChangeDemoninations[3].Value;
                        ktNum50 = ktChangeDemoninations[3].Count;

                        MessageBox.Show("Thank you for using our vending machines. " +
                            "\n" +
                            "\n" + (ktDetectedMoney - ktAmountToPay) + " zł for you." +
                            "\nYour change is as it follows: " +
                            "\nNominal 5: " + ktNum5 +
                            "\nNominal 2: " + ktNum2 +
                            "\nNominal 1: " + ktNum1 +
                            "\nNominal 0.50: " + ktNum50 +
                            "\n" +
                            "\nHave a nice day!",
                            "Successful payment"
                            );
                        ktReset();
                        
                        ktCalcCapital();
                    }

                }
            }
            else if ((String)ktcmbChooseCurrency.SelectedItem == "EUR")
            {
                errorProvider1.Dispose();
                if (ktDetectedMoney > ktCalcCapitalEUR())
                    MessageBox.Show("I'm sorry but I can't give you a change. Could you pay by card?", "The message");
                else
                {
                    ktAmountToPay = (float)Math.Floor(ktAmountToPay / 4.00F);
                    if (ktDetectedMoney < ktAmountToPay)
                        errorProvider1.SetError(ktbtnPayByCash, "It's not enough money.");
                    else
                    {
                        errorProvider1.Dispose();
                        ktChange = ktDetectedMoney - ktAmountToPay;
                        
                        ktCalcChange(ktDemoninationContainerEUR, ktChange, ktDenominationValuesEUR);
                       
                        float ktNominalType2 = 2;
                        float ktNominalType1 = 1;
                        float ktNominalType50 = 0.50F;
                        float ktNum2 = 0;
                        float ktNum1 = 0;
                        float ktNum50 = 0;

                        ktNominalType2 = ktChangeDemoninations[0].Value;
                        ktNum2 = ktChangeDemoninations[0].Count;

                        ktNominalType1 = ktChangeDemoninations[1].Value;
                        ktNum1 = ktChangeDemoninations[1].Count;

                        ktNominalType50 = ktChangeDemoninations[2].Value;
                        ktNum50 = ktChangeDemoninations[2].Count;

                        MessageBox.Show("Thank you for using our vending machines. " +
                            "\n" +
                            "\n" + (ktDetectedMoney - ktAmountToPay) + " euro for you." +
                            "\nYour change is as it follows: " +
                            "\nNominal 2: " + ktNum2 +
                            "\nNominal 1: " + ktNum1 +
                            "\nNominal 0.50: " + ktNum50 +
                            "\n" +
                            "\nHave a nice day!",
                            "Successful payment"
                            );
                        ktReset();
                        int ktAmount = 0;
                        kttxtAmountToPay.Text = ktAmount.ToString();
                        kttxtDetectedMoneyEUR.Text = ((float)Math.Floor(ktAmountToPay / 4.00F)).ToString();
                        ktCalcCapitalEUR();
                    }

                }
            }
        }

        public void ktReset()
        {
            ktNumProducts = 0;
            ktAmountToPay = 0;
            ktDetectedMoney = 0;
            ktChange = 0;
            kttxtNumProducts.Text = ktNumProducts.ToString();
            kttxtAmountToPay.Text = ktAmountToPay.ToString();
            kttxtDetectedMoney.Text = ktDetectedMoney.ToString();
        }

        private void ktcmbChooseCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((String)ktcmbChooseCurrency.SelectedItem == "EUR")
            {
                ktbtn5.Enabled = false;
                kttxtDetectedMoneyEUR.Visible = true;
                ktlblEur.Visible = true;
                kttxtDetectedMoneyEUR.Text = ((float)Math.Floor(ktAmountToPay / 4.00F)).ToString();
            }
            else
            {
                ktbtn5.Enabled = true;
                kttxtDetectedMoneyEUR.Visible = false;
                ktlblEur.Visible = false;
            }
        }
    }
}
